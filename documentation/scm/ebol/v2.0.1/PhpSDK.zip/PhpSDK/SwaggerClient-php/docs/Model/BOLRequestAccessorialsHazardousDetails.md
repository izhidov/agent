# BOLRequestAccessorialsHazardousDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emergency_contact** | [**\Swagger\Client\Model\BOLRequestAccessorialsHazardousDetailsEmergencyContact**](BOLRequestAccessorialsHazardousDetailsEmergencyContact.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

