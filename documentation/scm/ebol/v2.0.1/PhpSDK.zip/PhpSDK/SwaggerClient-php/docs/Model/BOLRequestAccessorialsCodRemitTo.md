# BOLRequestAccessorialsCodRemitTo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Name of the remit to company. | [optional] 
**address1** | **string** | Primary Address line of the remit to company. | [optional] 
**address2** | **string** | Secondary Address of the remit to company. | [optional] 
**city** | **string** | City Name of the remit to company. | [optional] 
**state_province** | **string** | Two letter state/province code of the remit to company.  Valid Values: See the State_Province_Codes schema at the bottom of this page. | [optional] 
**postal_code** | **string** | The 5-digit (or 6-characters for Canada) zip code of the remit to company.  Valid formats: * 12345 (5 digits - USA/MEX) * A1A1A1 (6 characters - CAN) * A1A1A (5 characters - CAN) | [optional] 
**country** | **string** | Three letter country code of the remit to company.  Valid Values: See the Country_Codes schema at the bottom of this page. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

