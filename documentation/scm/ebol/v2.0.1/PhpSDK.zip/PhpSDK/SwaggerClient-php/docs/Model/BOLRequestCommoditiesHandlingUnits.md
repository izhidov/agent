# BOLRequestCommoditiesHandlingUnits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Number of handling units being described | 
**type** | **string** | Type of the handling units being described  Valid Values: See the Handling_Unit_Types schema at the bottom of this page | 
**tare_weight** | **int** | Weight of the skids/pallets/slips used in the shipment. | [optional] 
**weight** | **int** | Total weight for the specified handling units. | 
**weight_unit** | **string** | The unit of measurement for weight.  Defaults to Pounds (Imperial) if not passed.  Valid Values: Pounds or Kilograms | [optional] 
**length** | **int** | The length of the handling units being described. | [optional] 
**width** | **int** | The width of the handling units being described. | [optional] 
**height** | **int** | The height of the handling units being described. | [optional] 
**dimensions_unit** | **string** | The unit of measurement for dimensions.  Defaults to Inches (Imperial) if not passed.  Valid Values: Inches or Centimeters | [optional] 
**stackable** | **bool** | Identifies whether or not the freight being described can be stacked on one another.  Default is false. | [optional] 
**line_items** | [**\Swagger\Client\Model\BOLRequestCommoditiesLineItems[]**](BOLRequestCommoditiesLineItems.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

