# BOLRequestReferenceNumbersAdditionalReferences

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Indicates the name of the reference number being provided. | [optional] 
**value** | **string** | Additional reference number that correlates to the additional reference name. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

