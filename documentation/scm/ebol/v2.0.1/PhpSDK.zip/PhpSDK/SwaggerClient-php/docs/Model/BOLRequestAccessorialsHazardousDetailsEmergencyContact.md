# BOLRequestAccessorialsHazardousDetailsEmergencyContact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Full name of who should be contacted in the case of a hazardous materials-related issue. | [optional] 
**phone** | **string** | Phone number of who should be contacted in the case of a hazardous materials-related issue.  Valid Formats: * ########## (10 digits - Area code + phone) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

