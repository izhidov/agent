# BOLRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bol** | [**\Swagger\Client\Model\BOLRequestBol**](BOLRequestBol.md) |  | 
**version** | **string** | Indicates which minor version of the Digital LTL Council Bill of Lading spec you are consuming      Valid values: v1.0 or v1.1 | 
**images** | [**\Swagger\Client\Model\BOLRequestImages**](BOLRequestImages.md) |  | [optional] 
**notifications** | [**\Swagger\Client\Model\BOLRequestNotifications[]**](BOLRequestNotifications.md) | include if you want notifications of shipment movements by text message or email | [optional] 
**reference_numbers** | [**\Swagger\Client\Model\BOLRequestReferenceNumbers**](BOLRequestReferenceNumbers.md) |  | [optional] 
**payment** | [**\Swagger\Client\Model\BOLRequestPayment**](BOLRequestPayment.md) |  | 
**commodities** | [**\Swagger\Client\Model\BOLRequestCommodities**](BOLRequestCommodities.md) |  | 
**shipment_totals** | [**\Swagger\Client\Model\BOLRequestShipmentTotals**](BOLRequestShipmentTotals.md) |  | [optional] 
**accessorials** | [**\Swagger\Client\Model\BOLRequestAccessorials**](BOLRequestAccessorials.md) |  | [optional] 
**origin** | [**\Swagger\Client\Model\BOLRequestOrigin**](BOLRequestOrigin.md) |  | 
**destination** | [**\Swagger\Client\Model\BOLRequestDestination**](BOLRequestDestination.md) |  | 
**bill_to** | [**\Swagger\Client\Model\BOLRequestBillTo**](BOLRequestBillTo.md) |  | 
**customs_broker** | [**\Swagger\Client\Model\BOLRequestCustomsBroker**](BOLRequestCustomsBroker.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

