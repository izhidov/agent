# BOLRequestReferenceNumbersPo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **string** | The Purchase Order number. | [optional] 
**pieces** | **int** | Total pieces associated with the Purchase Order | [optional] 
**weight** | **int** | Total weight associated with the Purchase Order | [optional] 
**palletized** | **bool** | Indicates whether or not the pieces associated with the purchase order are on a pallet/slip/skid or not. | [optional] 
**additional_shipper_info** | **string** | Additional information from shipper per line item | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

