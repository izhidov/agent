# BOLRequestReferenceNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pro** | **string** | Shipper&#x27;s pre-assigned PRO number for the requested carrier. If not provided, one will be auto assigned by the carrier. | [optional] 
**quote_id** | **string** | Quote (estimate) number provided by the carrier after submitting a rate quote request. | [optional] 
**shipment_id** | **string** | Shipment Id (SID) number for the shipment. | [optional] 
**master_bol** | **string** | Master Bill of Lading number for the shipment. | [optional] 
**bol** | **string[]** |  | [optional] 
**po** | [**\Swagger\Client\Model\BOLRequestReferenceNumbersPo[]**](BOLRequestReferenceNumbersPo.md) |  | [optional] 
**additional_references** | [**\Swagger\Client\Model\BOLRequestReferenceNumbersAdditionalReferences[]**](BOLRequestReferenceNumbersAdditionalReferences.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

