# BOLRequestImagesEmail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**include_bol** | **bool** | Used to request the bill of lading PDF to be sent to one or more email addresses | [optional] 
**include_labels** | **bool** | Used to request the shipping labels PDF to be sent to one or more email addresses | [optional] 
**addresses** | **string[]** | Provide one or more email addresses to receive the bol and/or shipping labels PDF | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

