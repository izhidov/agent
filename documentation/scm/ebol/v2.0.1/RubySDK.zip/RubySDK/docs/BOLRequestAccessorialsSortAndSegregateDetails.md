# SwaggerClient::BOLRequestAccessorialsSortAndSegregateDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pieces** | **Integer** | Number of pieces in a shipment to be sorted/segregated | [optional] 

