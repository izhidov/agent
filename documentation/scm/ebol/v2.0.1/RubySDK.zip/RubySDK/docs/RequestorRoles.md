# SwaggerClient::RequestorRoles

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

