# SwaggerClient::CarrierAPIStandardsApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**bol_v1_app_post**](CarrierAPIStandardsApi.md#bol_v1_app_post) | **POST** /bol/v1/app/ | 

# **bol_v1_app_post**
> BOLResponse bol_v1_app_post(body)



### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CarrierAPIStandardsApi.new
body = SwaggerClient::BOLRequest.new # BOLRequest | 


begin
  result = api_instance.bol_v1_app_post(body)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CarrierAPIStandardsApi->bol_v1_app_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BOLRequest**](BOLRequest.md)|  | 

### Return type

[**BOLResponse**](BOLResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



