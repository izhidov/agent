# SwaggerClient::BOLRequestCustomsBroker

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | Used to identify a customs broker that is involved in a cross-border freight move.  Valid Values: Import or Export   * Import: customs broker handling the destination-side of the cross-border freight move   * Export: customs broker handling the origin-side of the cross-border freight move  | [optional] 
**name** | **String** | Company name associated with the customsBroker location. | [optional] 
**address1** | **String** | Primary Address line for the customsBroker location | [optional] 
**address2** | **String** | Secondary Address line for the customsBroker location | [optional] 
**city** | **String** | City Name for the customsBroker location | [optional] 
**state_province** | **String** | Two letter state/province code for the customsBroker location.  Valid Values: See the State_Province_Codes schema at the bottom of this page.  | [optional] 
**postal_code** | **String** | The 5-digit (or 6-characters for Canada) zip code ofor the customsBroker location.  Valid formats:   * 12345 (5 digits - USA/MEX)   * A1A1A1 (6 characters - CAN)   * A1A1A (5 characters - CAN)  | [optional] 
**country** | **String** | Three letter country code for the customsBroker location.  Valid Values: See the Country_Codes schema at the bottom of this page.  | [optional] 
**contact** | [**BOLRequestCustomsBrokerContact**](BOLRequestCustomsBrokerContact.md) |  | [optional] 

