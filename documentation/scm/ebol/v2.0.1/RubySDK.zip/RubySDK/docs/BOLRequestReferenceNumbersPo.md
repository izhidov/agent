# SwaggerClient::BOLRequestReferenceNumbersPo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **String** | The Purchase Order number. | [optional] 
**pieces** | **Integer** | Total pieces associated with the Purchase Order | [optional] 
**weight** | **Integer** | Total weight associated with the Purchase Order | [optional] 
**palletized** | **BOOLEAN** | Indicates whether or not the pieces associated with the purchase order are on a pallet/slip/skid or not. | [optional] 
**additional_shipper_info** | **String** | Additional information from shipper per line item | [optional] 

