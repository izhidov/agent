# SwaggerClient::BOLRequestAccessorialsMarkDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pieces** | **Integer** | Number of pieces in a shipment requiring marking or tagging | [optional] 

