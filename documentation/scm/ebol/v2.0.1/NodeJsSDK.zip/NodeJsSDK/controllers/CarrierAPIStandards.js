'use strict';

var utils = require('../utils/writer.js');
var CarrierAPIStandards = require('../service/CarrierAPIStandardsService');

module.exports.bolV1AppPOST = function bolV1AppPOST (req, res, next, body) {
  CarrierAPIStandards.bolV1AppPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
