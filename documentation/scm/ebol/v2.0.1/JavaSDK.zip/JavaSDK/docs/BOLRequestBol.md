# BOLRequestBol

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestedPickupDate** | **String** | The intended Ship Date. NOTE this does not serve as a Pickup Request  Valid Formats: * YYYY-MM-DDTHH:mm:ss.sss (ISO 8601)  | 
**function** | **String** | The intent for the submitted request.  Valid Values: * Create - Used for initial creation  | 
**isTest** | **Boolean** | Indicates whether or not the submitted request is intended to be a test or not. | 
**requestorRole** | **String** | Identifies the party making the request.  Valid Values: See Requestor_Roles schema at the bottom of this page.  | 
**specialInstructions** | **String** | Special delivery instructions that need to be followed for the shipment&#x27;s delivery. |  [optional]
