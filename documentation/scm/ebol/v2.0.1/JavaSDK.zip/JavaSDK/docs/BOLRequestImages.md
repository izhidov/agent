# BOLRequestImages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**includeBol** | **Boolean** | Indicates whether or not you want an image of the populated BOL returned in the response.   Default is false.  |  [optional]
**includeShippingLabels** | **Boolean** | Indicates whether or not you want image(s) of the shipping labels returned in the response.   Default is false.  |  [optional]
**shippingLabels** | [**BOLRequestImagesShippingLabels**](BOLRequestImagesShippingLabels.md) |  |  [optional]
**email** | [**BOLRequestImagesEmail**](BOLRequestImagesEmail.md) |  |  [optional]
