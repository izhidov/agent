# BOLRequestAccessorialsTimeCriticalDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | Type of delivery required for the requested Time Critical Service.  Required when accessorials.code list include TCS.  Valid Values: See the Time_Critical_Types schema at the bottom of this page.  |  [optional]
**date** | [**BOLRequestAccessorialsTimeCriticalDetailsDate**](BOLRequestAccessorialsTimeCriticalDetailsDate.md) |  |  [optional]
