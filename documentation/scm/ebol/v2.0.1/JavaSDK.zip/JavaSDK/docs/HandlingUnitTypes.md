# HandlingUnitTypes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
