# BOLResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** | Indicates which version of the Digital LTL Council Bill of Lading spec was returned |  [optional]
**transactionDate** | **String** | The date associated with this electronic bill of lading transaction. |  [optional]
**referenceNumbers** | [**BOLResponseReferenceNumbers**](BOLResponseReferenceNumbers.md) |  |  [optional]
**images** | [**BOLResponseImages**](BOLResponseImages.md) |  |  [optional]
**messageStatus** | [**BOLResponseMessageStatus**](BOLResponseMessageStatus.md) |  |  [optional]
