# BOLResponseImages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bol** | **String** | Base 64 encoded PDF of the populated Bill Of Lading |  [optional]
**shippingLabels** | **String** | Base 64 encoded PDF of the populated shipping labels |  [optional]
