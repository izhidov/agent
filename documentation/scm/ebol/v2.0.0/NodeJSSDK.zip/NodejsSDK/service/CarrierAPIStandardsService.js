'use strict';


/**
 *
 * body BOL_Request 
 * returns BOL_Response
 **/
exports.bolV1AppPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "messageStatus" : {
    "code" : "10000000",
    "information" : [ ],
    "message" : "Transaction was successful.",
    "resolution" : "",
    "status" : "PASS"
  },
  "images" : {
    "bol" : "JVBERi0xLjcKCjQgMCBvYmoKPDwKL0JpdHNQZXJDb21wb25lbnQgOAovQ29sb3JTcGFjZSAvRGV2a......",
    "shippingLabels" : "JVBERi0xLjcKCjQgMCBvYmoKPDwKL0JpdHNQZXJDb21wb25lbnQgOAovQ29sb3JTcGFjZSAvRGV2a......"
  },
  "transactionDate" : "2022-11-20T00:00:00.000",
  "referenceNumbers" : {
    "shipmentConfirmationNumber" : "SCN1234",
    "pro" : "PRO1234"
  },
  "version" : "v1"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

