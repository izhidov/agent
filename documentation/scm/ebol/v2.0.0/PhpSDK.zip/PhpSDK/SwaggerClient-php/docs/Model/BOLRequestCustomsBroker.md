# BOLRequestCustomsBroker

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **string** | Used to identify a customs broker that is involved in a cross-border freight move.  Valid Values: Import or Export   * Import: customs broker handling the destination-side of the cross-border freight move   * Export: customs broker handling the origin-side of the cross-border freight move | [optional] 
**name** | **string** | Company name associated with the customsBroker location. | [optional] 
**address1** | **string** | Primary Address line for the customsBroker location | [optional] 
**address2** | **string** | Secondary Address line for the customsBroker location | [optional] 
**city** | **string** | City Name for the customsBroker location | [optional] 
**state_province** | **string** | Two letter state/province code for the customsBroker location.  Valid Values: See the State_Province_Codes schema at the bottom of this page. | [optional] 
**postal_code** | **string** | The 5-digit (or 6-characters for Canada) zip code ofor the customsBroker location.  Valid formats:   * 12345 (5 digits - USA/MEX)   * A1A1A1 (6 characters - CAN)   * A1A1A (5 characters - CAN) | [optional] 
**country** | **string** | Three letter country code for the customsBroker location.  Valid Values: See the Country_Codes schema at the bottom of this page. | [optional] 
**contact** | [**\Swagger\Client\Model\BOLRequestCustomsBrokerContact**](BOLRequestCustomsBrokerContact.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

