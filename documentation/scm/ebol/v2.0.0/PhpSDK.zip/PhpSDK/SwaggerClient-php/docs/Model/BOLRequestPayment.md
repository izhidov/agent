# BOLRequestPayment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terms** | **string** | Freight Billing Terms for the shipment  Valid Values: See the Payment_Terms schema at the bottom of this page. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

