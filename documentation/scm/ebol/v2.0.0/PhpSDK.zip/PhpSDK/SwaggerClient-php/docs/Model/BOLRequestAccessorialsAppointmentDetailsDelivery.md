# BOLRequestAccessorialsAppointmentDetailsDelivery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start** | **string** | Starting appointment date (with or without time) the shipment is requested to be delivered.  Required when accessorials.code list include APTD.  Valid Formats: * YYYY-MM-DDTHH:mm:ss.sss (ISO 8601) | [optional] 
**end** | **string** | Ending appointment date (with or without time) the shipment is requested to be delivered.  Valid Formats: * YYYY-MM-DDTHH:mm:ss.sss (ISO 8601) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

