# BOLRequestAccessorialsMarkDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pieces** | **int** | Number of pieces in a shipment requiring marking or tagging | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

