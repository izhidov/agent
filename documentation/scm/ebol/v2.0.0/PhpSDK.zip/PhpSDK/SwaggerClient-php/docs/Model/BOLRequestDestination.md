# BOLRequestDestination

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | **string** | Company&#x27;s account number/id for the destination. | [optional] 
**location_id** | **string** | Company&#x27;s location id for the destination | [optional] 
**name** | **string** | Company name associated with the destination location. | 
**address1** | **string** | Primary Address line for the destination location | 
**address2** | **string** | Secondary Address line for the destination location | [optional] 
**city** | **string** | City Name for the destination location | 
**state_province** | **string** | Two letter state/province code for the destination location.  Valid Values: See the State_Province_Codes schema at the bottom of this page. | 
**postal_code** | **string** | The 5-digit (or 6-characters for Canada) zip code ofor the destination location.  Valid formats:   * 12345 (5 digits - USA/MEX)   * A1A1A1 (6 characters - CAN)   * A1A1A (5 characters - CAN) | 
**country** | **string** | Three letter country code for the destination location.  Valid Values: See the Country_Codes schema at the bottom of this page. | 
**contact** | [**\Swagger\Client\Model\BOLRequestDestinationContact**](BOLRequestDestinationContact.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

