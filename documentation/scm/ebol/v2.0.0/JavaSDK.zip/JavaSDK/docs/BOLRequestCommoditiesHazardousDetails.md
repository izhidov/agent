# BOLRequestCommoditiesHazardousDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weight** | **Integer** | Total weight of hazardous material coveraged by one description. |  [optional]
**propertyClass** | **String** | Class that the hazardous material is catogorized by. |  [optional]
**unnaNumber** | **String** | Proper Identification Number (UN or NA) corresponding to the Proper Shipping Name |  [optional]
**propername** | **String** | Proper shipping name for the hazardous material.  From DOT regulations 172.101  |  [optional]
**technicalName** | **String** | Technical name for the hazardous material. Not all hazardous items will have a technical name.  From DOT regulations 172.101  |  [optional]
**packingGroup** | **String** | Hazmat Packing Group number. Not all hazmat items have a packing group |  [optional]
**contractNumber** | **String** | The contract number with the hazardous materials contact |  [optional]
