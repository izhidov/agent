# BOLResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**referenceNumbers** | [**BOLResponseReferenceNumbers**](BOLResponseReferenceNumbers.md) |  |  [optional]
**images** | [**BOLResponseImages**](BOLResponseImages.md) |  |  [optional]
**messageStatus** | [**BOLResponseMessageStatus**](BOLResponseMessageStatus.md) |  |  [optional]
