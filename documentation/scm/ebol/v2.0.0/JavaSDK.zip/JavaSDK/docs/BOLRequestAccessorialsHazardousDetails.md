# BOLRequestAccessorialsHazardousDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emergencyContact** | [**BOLRequestAccessorialsHazardousDetailsEmergencyContact**](BOLRequestAccessorialsHazardousDetailsEmergencyContact.md) |  |  [optional]
