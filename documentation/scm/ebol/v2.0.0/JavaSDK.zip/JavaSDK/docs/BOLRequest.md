# BOLRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bol** | [**BOLRequestBol**](BOLRequestBol.md) |  | 
**images** | [**BOLRequestImages**](BOLRequestImages.md) |  |  [optional]
**referenceNumbers** | [**BOLRequestReferenceNumbers**](BOLRequestReferenceNumbers.md) |  |  [optional]
**payment** | [**BOLRequestPayment**](BOLRequestPayment.md) |  | 
**commodities** | [**BOLRequestCommodities**](BOLRequestCommodities.md) |  | 
**shipmentTotals** | [**BOLRequestShipmentTotals**](BOLRequestShipmentTotals.md) |  |  [optional]
**accessorials** | [**BOLRequestAccessorials**](BOLRequestAccessorials.md) |  |  [optional]
**origin** | [**BOLRequestOrigin**](BOLRequestOrigin.md) |  | 
**destination** | [**BOLRequestDestination**](BOLRequestDestination.md) |  | 
**billTo** | [**BOLRequestBillTo**](BOLRequestBillTo.md) |  | 
**customsBroker** | [**BOLRequestCustomsBroker**](BOLRequestCustomsBroker.md) |  |  [optional]
