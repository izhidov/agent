# BOLRequestDestinationContact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phone** | **String** | Ten digit phone number, without country code and/or dashes, for the destination location&#x27;s contact person.  Valid Formats: * ########## (10 digits - Area code + phone)  | 
**phoneExt** | **String** | Phone extensionfor the destination location&#x27;s contact person. |  [optional]
**name** | **String** | Name of the destination location&#x27;s contact person. |  [optional]
**email** | **String** | Email address of the destination location&#x27;s contact person. |  [optional]
