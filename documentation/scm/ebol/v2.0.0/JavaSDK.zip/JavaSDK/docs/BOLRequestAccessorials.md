# BOLRequestAccessorials

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codes** | **List&lt;String&gt;** | An array to hold the list of services requested for the shipment\&quot;  Valid Values: See the Accessorial_Codes schema at the bottom of this page.  |  [optional]
**hazardousDetails** | [**BOLRequestAccessorialsHazardousDetails**](BOLRequestAccessorialsHazardousDetails.md) |  |  [optional]
**cod** | [**BOLRequestAccessorialsCod**](BOLRequestAccessorialsCod.md) |  |  [optional]
**sortAndSegregateDetails** | [**BOLRequestAccessorialsSortAndSegregateDetails**](BOLRequestAccessorialsSortAndSegregateDetails.md) |  |  [optional]
**excessLiabilityDetails** | [**BOLRequestAccessorialsExcessLiabilityDetails**](BOLRequestAccessorialsExcessLiabilityDetails.md) |  |  [optional]
**markDetails** | [**BOLRequestAccessorialsMarkDetails**](BOLRequestAccessorialsMarkDetails.md) |  |  [optional]
**limitedAccessType** | [**BOLRequestAccessorialsLimitedAccessType**](BOLRequestAccessorialsLimitedAccessType.md) |  |  [optional]
**timeCriticalDetails** | [**BOLRequestAccessorialsTimeCriticalDetails**](BOLRequestAccessorialsTimeCriticalDetails.md) |  |  [optional]
**appointmentDetails** | [**BOLRequestAccessorialsAppointmentDetails**](BOLRequestAccessorialsAppointmentDetails.md) |  |  [optional]
