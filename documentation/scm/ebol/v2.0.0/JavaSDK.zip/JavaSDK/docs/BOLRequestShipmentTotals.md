# BOLRequestShipmentTotals

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**grossWeight** | **Integer** | Gross weight (in pounds) of the entire shipment. |  [optional]
**netWeight** | **Integer** | Net weight (in pounds) of the entire shipment. |  [optional]
**handlingUnits** | **Integer** | Handling unit count for the entire shipment |  [optional]
**linearLength** | **Integer** | Linear length (in inches) for the entire shipment |  [optional]
**cubicFeet** | **Integer** | Cubic feet of the entire shipment. |  [optional]
