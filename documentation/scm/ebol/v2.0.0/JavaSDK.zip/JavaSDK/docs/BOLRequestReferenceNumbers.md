# BOLRequestReferenceNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pro** | **String** | Shipper&#x27;s pre-assigned PRO number for the requested carrier. If not provided, one will be auto assigned by the carrier. |  [optional]
**estimate** | **String** | Estimate number provided by the carrier after submitting a rate estimate request. |  [optional]
**shipmentId** | **String** | Shipment Id (SID) number for the shipment. |  [optional]
**masterBol** | **String** | Master Bill of Lading number for the shipment. |  [optional]
**bol** | **List&lt;String&gt;** |  |  [optional]
**po** | [**List&lt;BOLRequestReferenceNumbersPo&gt;**](BOLRequestReferenceNumbersPo.md) |  |  [optional]
**additionalReferences** | [**List&lt;BOLRequestReferenceNumbersAdditionalReferences&gt;**](BOLRequestReferenceNumbersAdditionalReferences.md) |  |  [optional]
