# BOLRequestCommoditiesLineItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**handlingUnitId** | **String** | Unique identifier for the user to associate handling units with line items. |  [optional]
**description** | **String** | Description of the freight being described. | 
**weight** | **Integer** | Total weight (in pounds) for the specified lineItem. | 
**pieces** | **Integer** | Number of individual pieces for the line item being described. | 
**packagingType** | **String** | Packaging type for the individual pieces of the line item being described.  Valid Values: See the Packaging_Types schema at the bottom of this page  | 
**classification** | **String** | Classification of the line item beind described.  Valid Values: See the Classification_Codes schema at the bottom of this page.  | 
**nmfc** | **String** | NMFC code of the freight being described. |  [optional]
**nmfcSub** | **String** | The Sub value for the NMFC of the freight being described. |  [optional]
**hazardous** | **Boolean** | Identifies whether or not the freight being described ciontains hazardous materials. | 
**hazardousDetails** | [**BOLRequestCommoditiesHazardousDetails**](BOLRequestCommoditiesHazardousDetails.md) |  |  [optional]
