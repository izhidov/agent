# LimitedAccessTypes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
