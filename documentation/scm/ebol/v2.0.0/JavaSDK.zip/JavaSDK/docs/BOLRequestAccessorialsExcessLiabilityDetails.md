# BOLRequestAccessorialsExcessLiabilityDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**monetaryValue** | **String** | Value of the cargo.   Valid Formats: * ##.## (2 decimal places only)  |  [optional]
**excessDeclaredValue** | **String** | Excess of declared value purchased for cargo.   Valid Formats: * ##.## (2 decimal places only)  |  [optional]
