# SwaggerClient::BOLRequestAccessorialsFullValueCoverageDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**monetary_value** | **String** | Value of the cargo.   Valid Formats: * ##.## (2 decimal places only)  | [optional] 
**currency** | **String** | Optional attribute to indicate currency of monetaryValue. Defaults to USD.  Valid values: See the Currencies schema at the bottom of this page.  | [optional] 

