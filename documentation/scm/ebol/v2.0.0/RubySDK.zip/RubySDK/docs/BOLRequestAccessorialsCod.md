# SwaggerClient::BOLRequestAccessorialsCod

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **String** | Amount to be received for the COD.  Valid Formats: * ##.## (2 decimal places only)  | [optional] 
**currency** | **String** | Optional attribute to indicate currency of COD. Defaults to USD.  Valid values: See the Currencies schema at the bottom of this page.  | [optional] 
**terms** | **String** | Payment terms associated with the COD.  Valid Values: * Prepaid * Collect  | [optional] 
**customer_check_acceptable** | **BOOLEAN** | Indicates whether or not a customer check or cash is acceptable. | [optional] 
**remit_to** | [**BOLRequestAccessorialsCodRemitTo**](BOLRequestAccessorialsCodRemitTo.md) |  | [optional] 

