# SwaggerClient::BOLRequestAccessorialsExcessLiabilityDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**monetary_value** | **String** | Value of the cargo.   Valid Formats: * ##.## (2 decimal places only)  | [optional] 
**excess_declared_value** | **String** | Excess of declared value purchased for cargo.   Valid Formats: * ##.## (2 decimal places only)  | [optional] 

