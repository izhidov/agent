# SwaggerClient::BOLResponseImages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bol** | **String** | Base 64 encoded PDF of the populated Bill Of Lading | [optional] 
**shipping_labels** | **String** | Base 64 encoded PDF of the populated shipping labels | [optional] 

