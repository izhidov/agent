# SwaggerClient::BOLResponseMessageStatusInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**message** | **String** |  | [optional] 

