# SwaggerClient::BOLRequestAccessorialsAppointmentDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pickup** | [**BOLRequestAccessorialsAppointmentDetailsPickup**](BOLRequestAccessorialsAppointmentDetailsPickup.md) |  | [optional] 
**delivery** | [**BOLRequestAccessorialsAppointmentDetailsDelivery**](BOLRequestAccessorialsAppointmentDetailsDelivery.md) |  | [optional] 

