# SwaggerClient::BOLRequestImagesEmail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**include_bol** | **BOOLEAN** | Used to request the bill of lading PDF to be sent to one or more email addresses  | [optional] 
**include_labels** | **BOOLEAN** | Used to request the shipping labels PDF to be sent to one or more email addresses  | [optional] 
**addresses** | **Array&lt;String&gt;** | Provide one or more email addresses to receive the bol and/or shipping labels PDF  | [optional] 

