# SwaggerClient::BOLRequestImages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**include_bol** | **BOOLEAN** | Indicates whether or not you want an image of the populated BOL returned in the response.   Default is false.  | [optional] 
**include_shipping_labels** | **BOOLEAN** | Indicates whether or not you want image(s) of the shipping labels returned in the response.   Default is false.  | [optional] 
**shipping_labels** | [**BOLRequestImagesShippingLabels**](BOLRequestImagesShippingLabels.md) |  | [optional] 
**email** | [**BOLRequestImagesEmail**](BOLRequestImagesEmail.md) |  | [optional] 

