# SwaggerClient::BOLResponseMessageStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | Indicates the status of the request. &lt;br&gt;&lt;br&gt; PASS - Request is successful with no exceptions.&lt;br&gt; FAIL - Request is unsuccessful due to some exception.&lt;br&gt; WARNING - Request is successful with some exception.  | [optional] 
**code** | **String** | Indicates response detail code. | [optional] 
**message** | **String** | Provides information pertaining to the response code. | [optional] 
**resolution** | **String** | Provides guidance pertaining to the response code. | [optional] 
**information** | [**Array&lt;BOLResponseMessageStatusInformation&gt;**](BOLResponseMessageStatusInformation.md) |  | [optional] 

