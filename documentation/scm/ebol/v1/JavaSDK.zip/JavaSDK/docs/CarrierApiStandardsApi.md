# CarrierApiStandardsApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**bolV1AppPost**](CarrierApiStandardsApi.md#bolV1AppPost) | **POST** /bol/v1/app/ | 

<a name="bolV1AppPost"></a>
# **bolV1AppPost**
> BOLResponse bolV1AppPost(body)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CarrierApiStandardsApi;


CarrierApiStandardsApi apiInstance = new CarrierApiStandardsApi();
BOLRequest body = new BOLRequest(); // BOLRequest | 
try {
    BOLResponse result = apiInstance.bolV1AppPost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CarrierApiStandardsApi#bolV1AppPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BOLRequest**](BOLRequest.md)|  |

### Return type

[**BOLResponse**](BOLResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

