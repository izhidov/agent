# BOLRequestAccessorialsCod

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **String** | Amount to be received for the COD.  Valid Formats: * ##.## (2 decimal places only)  |  [optional]
**terms** | **String** | Payment terms associated with the COD.  Valid Values: * Prepaid * Collect  |  [optional]
**customerCheckAcceptable** | **Boolean** | Indicates whether or not a customer check or cash is acceptable. |  [optional]
**remitTo** | [**BOLRequestAccessorialsCodRemitTo**](BOLRequestAccessorialsCodRemitTo.md) |  |  [optional]
