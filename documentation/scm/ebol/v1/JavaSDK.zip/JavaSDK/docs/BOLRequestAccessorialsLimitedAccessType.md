# BOLRequestAccessorialsLimitedAccessType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**origin** | **String** | Required when accessorial code LTDAP is present in the accessorial.codes list.   Valid Values: See the Limited_Acess_Types schema at the bottom of this page.   |  [optional]
**destination** | **String** | Required when accessorial code LTDAD is present in the accessorial.codes list.   Valid Values: See the Limited_Acess_Types schema at the bottom of this page.   |  [optional]
