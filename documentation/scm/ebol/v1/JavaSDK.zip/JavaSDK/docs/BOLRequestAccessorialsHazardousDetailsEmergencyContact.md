# BOLRequestAccessorialsHazardousDetailsEmergencyContact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Full name of who should be contacted in the case of a hazardous materials-related issue. |  [optional]
**phone** | **String** | Phone number of who should be contacted in the case of a hazardous materials-related issue.  Valid Formats: * ########## (10 digits - Area code + phone)  |  [optional]
