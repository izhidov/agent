# BOLRequestImagesShippingLabels

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**format** | **String** | Specifies the printer format type for the labels.   Required when images.includeShippingLabels is true.   Valid Values: See the Shipping_Label_Formats schema at the bottom of this page.  |  [optional]
**quantity** | **Integer** | Specifies the quantity of labels desired.   Required when images.includeShippingLabels is true.  |  [optional]
**position** | **Integer** | Specifies the starting position for the shipping labels.  Required when images.shippingLabel is Avery.   Valid Values: * 1 - 6  |  [optional]
