# BOLResponseReferenceNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pro** | **String** | Shipper&#x27;s pre-assigned PRO number for the requested carrier. If one was not provided in the request, one will be auto assigned by the carrier. |  [optional]
**shipmentConfirmationNumber** | **String** | Number provided by the carrier to acknowledge they accepted the BOL. |  [optional]
