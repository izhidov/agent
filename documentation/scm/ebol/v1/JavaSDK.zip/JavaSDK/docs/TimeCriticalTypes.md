# TimeCriticalTypes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
