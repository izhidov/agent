# BOLRequestCommodities

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**handlingUnits** | [**List&lt;BOLRequestCommoditiesHandlingUnits&gt;**](BOLRequestCommoditiesHandlingUnits.md) |  | 
**lineItems** | [**List&lt;BOLRequestCommoditiesLineItems&gt;**](BOLRequestCommoditiesLineItems.md) |  | 
