# SwaggerClient::BOLRequestAccessorialsAppointmentDetailsDelivery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start** | **String** | Starting appointment date (with or without time) the shipment is requested to be delivered.  Required when accessorials.code list include APTD.  Valid Formats: * YYYY-MM-DDTHH:mm:ss.sss (ISO 8601)  | [optional] 
**_end** | **String** | Ending appointment date (with or without time) the shipment is requested to be delivered.  Valid Formats: * YYYY-MM-DDTHH:mm:ss.sss (ISO 8601)  | [optional] 

