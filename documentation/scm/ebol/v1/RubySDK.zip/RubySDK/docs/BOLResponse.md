# SwaggerClient::BOLResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reference_numbers** | [**BOLResponseReferenceNumbers**](BOLResponseReferenceNumbers.md) |  | [optional] 
**images** | [**BOLResponseImages**](BOLResponseImages.md) |  | [optional] 
**message_status** | [**BOLResponseMessageStatus**](BOLResponseMessageStatus.md) |  | [optional] 

