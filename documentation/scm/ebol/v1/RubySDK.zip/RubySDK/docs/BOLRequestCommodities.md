# SwaggerClient::BOLRequestCommodities

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**handling_units** | [**Array&lt;BOLRequestCommoditiesHandlingUnits&gt;**](BOLRequestCommoditiesHandlingUnits.md) |  | 
**line_items** | [**Array&lt;BOLRequestCommoditiesLineItems&gt;**](BOLRequestCommoditiesLineItems.md) |  | 

