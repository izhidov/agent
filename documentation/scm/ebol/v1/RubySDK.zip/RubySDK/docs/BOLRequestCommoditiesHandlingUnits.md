# SwaggerClient::BOLRequestCommoditiesHandlingUnits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Unique identifier for the user to associate the handling unit with one or more line items. | [optional] 
**count** | **Integer** | Number of handling units being described | 
**type** | **String** | Type of the handling units being described  Valid Values: See the Handling_Unit_Types schema at the bottom of this page  | 
**tare_weight** | **Integer** | Weight (in pounds) of the skids/pallets/slips used in the shipment. | [optional] 
**weight** | **Integer** | Total weight (in pounds) for the specified handling units | 
**length** | **Integer** | The length of the handling units being described (in inches). | 
**width** | **Integer** | The width of the handling units being described (in inches). | 
**height** | **Integer** | The height of the handling units being described (in inches). | 
**stackable** | **BOOLEAN** | Identifies whether or not the freight being described can be stacked on one another.  Default is false.  | [optional] 

