# SwaggerClient::BOLRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bol** | [**BOLRequestBol**](BOLRequestBol.md) |  | 
**images** | [**BOLRequestImages**](BOLRequestImages.md) |  | [optional] 
**reference_numbers** | [**BOLRequestReferenceNumbers**](BOLRequestReferenceNumbers.md) |  | [optional] 
**payment** | [**BOLRequestPayment**](BOLRequestPayment.md) |  | 
**commodities** | [**BOLRequestCommodities**](BOLRequestCommodities.md) |  | 
**shipment_totals** | [**BOLRequestShipmentTotals**](BOLRequestShipmentTotals.md) |  | [optional] 
**accessorials** | [**BOLRequestAccessorials**](BOLRequestAccessorials.md) |  | [optional] 
**origin** | [**BOLRequestOrigin**](BOLRequestOrigin.md) |  | 
**destination** | [**BOLRequestDestination**](BOLRequestDestination.md) |  | 
**bill_to** | [**BOLRequestBillTo**](BOLRequestBillTo.md) |  | 
**customs_broker** | [**BOLRequestCustomsBroker**](BOLRequestCustomsBroker.md) |  | [optional] 

