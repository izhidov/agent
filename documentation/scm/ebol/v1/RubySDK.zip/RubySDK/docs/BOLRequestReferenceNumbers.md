# SwaggerClient::BOLRequestReferenceNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pro** | **String** | Shipper&#x27;s pre-assigned PRO number for the requested carrier. If not provided, one will be auto assigned by the carrier. | [optional] 
**estimate** | **String** | Estimate number provided by the carrier after submitting a rate estimate request. | [optional] 
**shipment_id** | **String** | Shipment Id (SID) number for the shipment. | [optional] 
**master_bol** | **String** | Master Bill of Lading number for the shipment. | [optional] 
**bol** | **Array&lt;String&gt;** |  | [optional] 
**po** | [**Array&lt;BOLRequestReferenceNumbersPo&gt;**](BOLRequestReferenceNumbersPo.md) |  | [optional] 
**additional_references** | [**Array&lt;BOLRequestReferenceNumbersAdditionalReferences&gt;**](BOLRequestReferenceNumbersAdditionalReferences.md) |  | [optional] 

