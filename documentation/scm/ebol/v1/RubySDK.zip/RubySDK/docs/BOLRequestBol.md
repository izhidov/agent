# SwaggerClient::BOLRequestBol

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **String** | The date associated with the creation of the bill of lading, which is typically displayed on the actual paper bill of lading.  Valid Formats: * YYYY-MM-DDTHH:mm:ss.sss (ISO 8601)  | 
**function** | **String** | The intent for the submitted request.  Valid Values: * Create - Used for initial creation  | 
**is_test** | **BOOLEAN** | Indicates whether or not the submitted request is intended to be a test or not. | 
**requestor_role** | **String** | Identifies the party making the request.  Valid Values: See Requestor_Roles schema at the bottom of this page.  | 
**special_instructions** | **String** | Special delivery instructions that need to be followed for the shipment&#x27;s delivery. | [optional] 

