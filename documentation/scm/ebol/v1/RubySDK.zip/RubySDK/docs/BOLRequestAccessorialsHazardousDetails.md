# SwaggerClient::BOLRequestAccessorialsHazardousDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emergency_contact** | [**BOLRequestAccessorialsHazardousDetailsEmergencyContact**](BOLRequestAccessorialsHazardousDetailsEmergencyContact.md) |  | [optional] 

