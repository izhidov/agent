# SwaggerClient::BOLRequestAccessorials

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codes** | **Array&lt;String&gt;** | An array to hold the list of services requested for the shipment\&quot;  Valid Values: See the Accessorial_Codes schema at the bottom of this page.  | [optional] 
**hazardous_details** | [**BOLRequestAccessorialsHazardousDetails**](BOLRequestAccessorialsHazardousDetails.md) |  | [optional] 
**cod** | [**BOLRequestAccessorialsCod**](BOLRequestAccessorialsCod.md) |  | [optional] 
**sort_and_segregate_details** | [**BOLRequestAccessorialsSortAndSegregateDetails**](BOLRequestAccessorialsSortAndSegregateDetails.md) |  | [optional] 
**excess_liability_details** | [**BOLRequestAccessorialsExcessLiabilityDetails**](BOLRequestAccessorialsExcessLiabilityDetails.md) |  | [optional] 
**mark_details** | [**BOLRequestAccessorialsMarkDetails**](BOLRequestAccessorialsMarkDetails.md) |  | [optional] 
**limited_access_type** | [**BOLRequestAccessorialsLimitedAccessType**](BOLRequestAccessorialsLimitedAccessType.md) |  | [optional] 
**time_critical_details** | [**BOLRequestAccessorialsTimeCriticalDetails**](BOLRequestAccessorialsTimeCriticalDetails.md) |  | [optional] 
**appointment_details** | [**BOLRequestAccessorialsAppointmentDetails**](BOLRequestAccessorialsAppointmentDetails.md) |  | [optional] 

