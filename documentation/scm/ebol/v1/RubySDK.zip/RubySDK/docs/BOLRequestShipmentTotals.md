# SwaggerClient::BOLRequestShipmentTotals

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gross_weight** | **Integer** | Gross weight (in pounds) of the entire shipment. | [optional] 
**net_weight** | **Integer** | Net weight (in pounds) of the entire shipment. | [optional] 
**handling_units** | **Integer** | Handling unit count for the entire shipment | [optional] 
**linear_length** | **Integer** | Linear length (in inches) for the entire shipment | [optional] 
**cubic_feet** | **Integer** | Cubic feet of the entire shipment. | [optional] 

