# SwaggerClient::BOLResponseMessageStatusInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | [optional] 
**message** | **String** |  | [optional] 

