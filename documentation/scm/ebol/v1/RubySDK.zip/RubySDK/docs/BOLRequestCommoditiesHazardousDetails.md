# SwaggerClient::BOLRequestCommoditiesHazardousDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weight** | **Integer** | Total weight of hazardous material coveraged by one description. | [optional] 
**_class** | **String** | Class that the hazardous material is catogorized by. | [optional] 
**unna_number** | **String** | Proper Identification Number (UN or NA) corresponding to the Proper Shipping Name | [optional] 
**propername** | **String** | Proper shipping name for the hazardous material.  From DOT regulations 172.101  | [optional] 
**technical_name** | **String** | Technical name for the hazardous material. Not all hazardous items will have a technical name.  From DOT regulations 172.101  | [optional] 
**packing_group** | **String** | Hazmat Packing Group number. Not all hazmat items have a packing group | [optional] 
**contract_number** | **String** | The contract number with the hazardous materials contact | [optional] 

