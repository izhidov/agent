# BOLRequestCommoditiesLineItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**handling_unit_id** | **string** | Unique identifier for the user to associate handling units with line items. | [optional] 
**description** | **string** | Description of the freight being described. | 
**weight** | **int** | Total weight (in pounds) for the specified lineItem. | 
**pieces** | **int** | Number of individual pieces for the line item being described. | 
**packaging_type** | **string** | Packaging type for the individual pieces of the line item being described.  Valid Values: See the Packaging_Types schema at the bottom of this page | 
**classification** | **string** | Classification of the line item beind described.  Valid Values: See the Classification_Codes schema at the bottom of this page. | 
**nmfc** | **string** | NMFC code of the freight being described. | [optional] 
**nmfc_sub** | **string** | The Sub value for the NMFC of the freight being described. | [optional] 
**hazardous** | **bool** | Identifies whether or not the freight being described ciontains hazardous materials. | 
**hazardous_details** | [**\Swagger\Client\Model\BOLRequestCommoditiesHazardousDetails**](BOLRequestCommoditiesHazardousDetails.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

