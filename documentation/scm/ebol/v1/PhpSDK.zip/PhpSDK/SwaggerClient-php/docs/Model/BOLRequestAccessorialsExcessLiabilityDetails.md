# BOLRequestAccessorialsExcessLiabilityDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**monetary_value** | **string** | Value of the cargo.   Valid Formats: * ##.## (2 decimal places only) | [optional] 
**excess_declared_value** | **string** | Excess of declared value purchased for cargo.   Valid Formats: * ##.## (2 decimal places only) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

