# BOLResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reference_numbers** | [**\Swagger\Client\Model\BOLResponseReferenceNumbers**](BOLResponseReferenceNumbers.md) |  | [optional] 
**images** | [**\Swagger\Client\Model\BOLResponseImages**](BOLResponseImages.md) |  | [optional] 
**message_status** | [**\Swagger\Client\Model\BOLResponseMessageStatus**](BOLResponseMessageStatus.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

