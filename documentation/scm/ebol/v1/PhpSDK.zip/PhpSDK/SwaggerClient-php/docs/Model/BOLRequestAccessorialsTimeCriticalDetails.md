# BOLRequestAccessorialsTimeCriticalDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **string** | Type of delivery required for the requested Time Critical Service.  Required when accessorials.code list include TCS.  Valid Values: See the Time_Critical_Types schema at the bottom of this page. | [optional] 
**date** | [**\Swagger\Client\Model\BOLRequestAccessorialsTimeCriticalDetailsDate**](BOLRequestAccessorialsTimeCriticalDetailsDate.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

