# BOLRequestCommodities

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**handling_units** | [**\Swagger\Client\Model\BOLRequestCommoditiesHandlingUnits[]**](BOLRequestCommoditiesHandlingUnits.md) |  | 
**line_items** | [**\Swagger\Client\Model\BOLRequestCommoditiesLineItems[]**](BOLRequestCommoditiesLineItems.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

