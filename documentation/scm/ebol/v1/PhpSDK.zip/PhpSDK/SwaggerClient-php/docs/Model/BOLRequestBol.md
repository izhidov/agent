# BOLRequestBol

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **string** | The date associated with the creation of the bill of lading, which is typically displayed on the actual paper bill of lading.  Valid Formats: * YYYY-MM-DDTHH:mm:ss.sss (ISO 8601) | 
**function** | **string** | The intent for the submitted request.  Valid Values: * Create - Used for initial creation | 
**is_test** | **bool** | Indicates whether or not the submitted request is intended to be a test or not. | 
**requestor_role** | **string** | Identifies the party making the request.  Valid Values: See Requestor_Roles schema at the bottom of this page. | 
**special_instructions** | **string** | Special delivery instructions that need to be followed for the shipment&#x27;s delivery. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

