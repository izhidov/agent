# BOLRequestImagesShippingLabels

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**format** | **string** | Specifies the printer format type for the labels.   Required when images.includeShippingLabels is true.   Valid Values: See the Shipping_Label_Formats schema at the bottom of this page. | [optional] 
**quantity** | **int** | Specifies the quantity of labels desired.   Required when images.includeShippingLabels is true. | [optional] 
**position** | **int** | Specifies the starting position for the shipping labels.  Required when images.shippingLabel is Avery.   Valid Values: * 1 - 6 | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

