# BOLRequestCommoditiesHandlingUnits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | Unique identifier for the user to associate the handling unit with one or more line items. | [optional] 
**count** | **int** | Number of handling units being described | 
**type** | **string** | Type of the handling units being described  Valid Values: See the Handling_Unit_Types schema at the bottom of this page | 
**tare_weight** | **int** | Weight (in pounds) of the skids/pallets/slips used in the shipment. | [optional] 
**weight** | **int** | Total weight (in pounds) for the specified handling units | 
**length** | **int** | The length of the handling units being described (in inches). | 
**width** | **int** | The width of the handling units being described (in inches). | 
**height** | **int** | The height of the handling units being described (in inches). | 
**stackable** | **bool** | Identifies whether or not the freight being described can be stacked on one another.  Default is false. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

