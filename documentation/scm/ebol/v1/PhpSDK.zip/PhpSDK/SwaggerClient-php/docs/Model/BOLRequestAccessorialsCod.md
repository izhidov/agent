# BOLRequestAccessorialsCod

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **string** | Amount to be received for the COD.  Valid Formats: * ##.## (2 decimal places only) | [optional] 
**terms** | **string** | Payment terms associated with the COD.  Valid Values: * Prepaid * Collect | [optional] 
**customer_check_acceptable** | **bool** | Indicates whether or not a customer check or cash is acceptable. | [optional] 
**remit_to** | [**\Swagger\Client\Model\BOLRequestAccessorialsCodRemitTo**](BOLRequestAccessorialsCodRemitTo.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

