# BOLRequestShipmentTotals

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gross_weight** | **int** | Gross weight (in pounds) of the entire shipment. | [optional] 
**net_weight** | **int** | Net weight (in pounds) of the entire shipment. | [optional] 
**handling_units** | **int** | Handling unit count for the entire shipment | [optional] 
**linear_length** | **int** | Linear length (in inches) for the entire shipment | [optional] 
**cubic_feet** | **int** | Cubic feet of the entire shipment. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

