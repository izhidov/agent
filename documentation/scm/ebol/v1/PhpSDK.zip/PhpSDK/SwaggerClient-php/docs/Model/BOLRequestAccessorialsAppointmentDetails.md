# BOLRequestAccessorialsAppointmentDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pickup** | [**\Swagger\Client\Model\BOLRequestAccessorialsAppointmentDetailsPickup**](BOLRequestAccessorialsAppointmentDetailsPickup.md) |  | [optional] 
**delivery** | [**\Swagger\Client\Model\BOLRequestAccessorialsAppointmentDetailsDelivery**](BOLRequestAccessorialsAppointmentDetailsDelivery.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

