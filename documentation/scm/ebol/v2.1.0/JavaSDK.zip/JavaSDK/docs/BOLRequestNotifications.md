# BOLRequestNotifications

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phoneNumber** | **String** | Phone number of contact for updates about shipment movements |  [optional]
**email** | **String** | Email address of contact for updates about shipment movements |  [optional]
