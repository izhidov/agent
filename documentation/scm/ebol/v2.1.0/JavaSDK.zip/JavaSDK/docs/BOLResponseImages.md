# BOLResponseImages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bol** | **String** | Base 64 encoded PDF of the populated Bill Of Lading.  Any bar code within the image(s) should include the check digit when applicable. |  [optional]
**shippingLabels** | **String** | Base 64 encoded PDF of the populated shipping Labels.  Any bar code within the image(s) should include the check digit when applicable. |  [optional]
