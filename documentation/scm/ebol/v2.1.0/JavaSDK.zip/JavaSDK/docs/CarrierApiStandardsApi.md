# CarrierApiStandardsApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**bolV1AppPost**](CarrierApiStandardsApi.md#bolV1AppPost) | **POST** /bol/v1/app/ | Create an Electronic Bill of Lading
[**bolV1AppProDelete**](CarrierApiStandardsApi.md#bolV1AppProDelete) | **DELETE** /bol/v1/app/{pro} | Delete an Electronic Bill of Lading
[**bolV1AppProPut**](CarrierApiStandardsApi.md#bolV1AppProPut) | **PUT** /bol/v1/app/{pro} | Update an Electronic Bill of Lading

<a name="bolV1AppPost"></a>
# **bolV1AppPost**
> BOLResponse bolV1AppPost(body)

Create an Electronic Bill of Lading

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CarrierApiStandardsApi;


CarrierApiStandardsApi apiInstance = new CarrierApiStandardsApi();
BOLRequest body = new BOLRequest(); // BOLRequest | 
try {
    BOLResponse result = apiInstance.bolV1AppPost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CarrierApiStandardsApi#bolV1AppPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BOLRequest**](BOLRequest.md)|  |

### Return type

[**BOLResponse**](BOLResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="bolV1AppProDelete"></a>
# **bolV1AppProDelete**
> bolV1AppProDelete(pro)

Delete an Electronic Bill of Lading

This operation deletes an existing Electronic Bill of Lading.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CarrierApiStandardsApi;


CarrierApiStandardsApi apiInstance = new CarrierApiStandardsApi();
String pro = "pro_example"; // String | PRO Number of eBOL to update.
try {
    apiInstance.bolV1AppProDelete(pro);
} catch (ApiException e) {
    System.err.println("Exception when calling CarrierApiStandardsApi#bolV1AppProDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro** | **String**| PRO Number of eBOL to update. |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="bolV1AppProPut"></a>
# **bolV1AppProPut**
> BOLResponse bolV1AppProPut(body, pro)

Update an Electronic Bill of Lading

This operation updates an existing Electronic Bill of Lading.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CarrierApiStandardsApi;


CarrierApiStandardsApi apiInstance = new CarrierApiStandardsApi();
BOLRequest body = new BOLRequest(); // BOLRequest | 
String pro = "pro_example"; // String | PRO Number of eBOL to delete.
try {
    BOLResponse result = apiInstance.bolV1AppProPut(body, pro);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CarrierApiStandardsApi#bolV1AppProPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BOLRequest**](BOLRequest.md)|  |
 **pro** | **String**| PRO Number of eBOL to delete. |

### Return type

[**BOLResponse**](BOLResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

