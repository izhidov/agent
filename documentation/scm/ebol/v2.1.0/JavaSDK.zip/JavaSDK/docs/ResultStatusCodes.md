# ResultStatusCodes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
