# BOLRequestAccessorialsTimeCriticalDetailsDate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start** | **String** | The date (with or without time) the shipment is requested to be delivered.  Required when timeCriticalDetails.type is populated with any valid value.  Valid Formats: * YYYY-MM-DDTHH:mm:ss.sss (ISO 8601)  |  [optional]
**end** | **String** | The end date (with or without time) of the requested delivery window.  Required when the timeCriticalDetails.type is Delivery Window.  Valid Formats: * YYYY-MM-DDTHH:mm:ss.sss (ISO 8601)  |  [optional]
