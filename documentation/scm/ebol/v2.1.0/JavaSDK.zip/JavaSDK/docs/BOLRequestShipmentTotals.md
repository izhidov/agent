# BOLRequestShipmentTotals

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**grossWeight** | **Integer** | Total weight of the entire shipment, including handling units (tare weight). |  [optional]
**netWeight** | **Integer** | Total weight of the entire shipment, not including handling units (tare weight). |  [optional]
**weightUnit** | **String** | The unit of measurement for weight.  Defaults to Pounds (Imperial) if not passed.  Valid Values: Pounds or Kilograms  |  [optional]
**handlingUnits** | **Integer** | Handling unit count for the entire shipment |  [optional]
**linearLength** | **Integer** | Linear length for the entire shipment |  [optional]
**dimensionsUnit** | **String** | The unit of measurement for dimensions.  Defaults to Inches (Imperial) if not passed.  Valid Values: Inches or Centimeters  |  [optional]
**cube** | **Integer** | Cubic volume of the entire shipment (total length X total width X total height). |  [optional]
**cubeDimensionsUnit** | **String** | The unit of measurement for cubic dimensions.  Defaults to Feet (Imperial) if not passed.  Valid Values: Feet or Meters  |  [optional]
**declaredValue** | **Integer** | Total monetary value of the shipment in USD (sometimes needed for cross-border moves). |  [optional]
**currency** | **String** | Optional attribute to indicate currency of declaredValue. Defaults to USD.  Valid values: See the Currencies schema at the bottom of this page.  |  [optional]
