# BOLRequestReferenceNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pro** | **String** | Shipper&#x27;s pre-assigned PRO number for the requested carrier. If one was not provided in the request, one will be auto assigned by the carrier.  The PRO number value should include the check digit when applicable. |  [optional]
**quoteId** | **String** | Quote (estimate) number provided by the carrier after submitting a rate quote request. |  [optional]
**shipmentId** | **String** | Shipment Id (SID) number for the shipment. |  [optional]
**masterBol** | **String** | Master Bill of Lading number for the shipment. |  [optional]
**trailerId** | **String** | When passed, indicates that the shipment is associated to a specific, spotted trailer. |  [optional]
**manifestId** | **String** | When passed, indicates that the shipment is associated to a manifest that includes multiple shipments, possibly across multiple spotted trailers. |  [optional]
**bol** | **List&lt;String&gt;** |  |  [optional]
**po** | [**List&lt;BOLRequestReferenceNumbersPo&gt;**](BOLRequestReferenceNumbersPo.md) |  |  [optional]
**additionalReferences** | [**List&lt;BOLRequestReferenceNumbersAdditionalReferences&gt;**](BOLRequestReferenceNumbersAdditionalReferences.md) |  |  [optional]
