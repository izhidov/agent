# BOLResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** | Indicates which version of the Digital LTL Council Bill of Lading spec was returned |  [optional]
**transactionDate** | **String** | The date associated with this electronic bill of lading transaction. |  [optional]
**referenceNumbers** | [**BOLResponseReferenceNumbers**](BOLResponseReferenceNumbers.md) |  |  [optional]
**scac** | **String** | 4-letter, Standard Carrier Alpha Code, returned by the carrier. |  [optional]
**images** | [**BOLResponseImages**](BOLResponseImages.md) |  |  [optional]
**termsAndConditions** | **String** | Add terms and conditions here if desired, or a link to your  terms and conditions.     |  [optional]
**messageStatus** | [**BOLResponseMessageStatus**](BOLResponseMessageStatus.md) |  |  [optional]
**resultStatusCodes** | [**List&lt;ResultStatusCodes&gt;**](ResultStatusCodes.md) | Error response |  [optional]
