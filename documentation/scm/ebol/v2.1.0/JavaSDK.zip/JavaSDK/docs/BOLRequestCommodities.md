# BOLRequestCommodities

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lineItemLayout** | **String** |  Valid values: Nested or Stacked  Nested: Indicates if the Handling Unit/Line Item relationship is known. If this value is used, each Line Item associated to a Handling Unit is conditionally required to be passed within that Handling Unit&#x27;s object.  Stacked: Indicates if the Handling Unit/Line Item relationship is not known.  If this value is used, Line Items may passed within any Handling Unit object.  | 
**handlingUnits** | [**List&lt;BOLRequestCommoditiesHandlingUnits&gt;**](BOLRequestCommoditiesHandlingUnits.md) |  | 
