# BOLRequestReferenceNumbersAdditionalReferences

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Indicates the name of the reference number being provided.  |  [optional]
**value** | **String** | Additional reference number that correlates to the additional reference name. |  [optional]
