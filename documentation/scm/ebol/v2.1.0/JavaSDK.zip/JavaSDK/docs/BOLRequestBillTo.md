# BOLRequestBillTo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | **String** | Company&#x27;s account number/id for the billTo. |  [optional]
**locationId** | **String** | Company&#x27;s location id for the billTo. |  [optional]
**name** | **String** | Company name associated with the billTo location. | 
**address1** | **String** | Primary Address line for the billTo location | 
**address2** | **String** | Secondary Address line for the billTo location |  [optional]
**city** | **String** | City Name for the billTo location | 
**stateProvince** | **String** | Two letter state/province code for the billTo location.  Valid Values: See the State_Province_Codes schema at the bottom of this page.  | 
**postalCode** | **String** | The 5-digit + 4 or 5-digit for the United States, 5-digit for Mexico, or 6-character for Canada, postal code for the billTo location.  Valid formats:   * 12345-1234 (5 digits + 4 - USA)   * 12345 (5 digits - USA/MEX)   * A1A1A1 (6 characters - CAN)   * A1A1A (5 characters - CAN)  | 
**country** | **String** | Three letter country code for the billTo location.  Valid Values: See the Country_Codes schema at the bottom of this page.  | 
**contact** | [**BOLRequestBillToContact**](BOLRequestBillToContact.md) |  | 
