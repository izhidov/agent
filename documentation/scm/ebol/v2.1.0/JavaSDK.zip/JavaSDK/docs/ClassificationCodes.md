# ClassificationCodes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
