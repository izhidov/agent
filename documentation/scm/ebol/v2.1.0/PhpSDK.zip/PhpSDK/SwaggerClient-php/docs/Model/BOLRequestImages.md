# BOLRequestImages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**include_bol** | **bool** | Indicates whether or not you want an image of the populated BOL returned in the response.   Default is false. | [optional] 
**include_shipping_labels** | **bool** | Indicates whether or not you want image(s) of the shipping labels returned in the response.   Default is false. | [optional] 
**shipping_labels** | [**\Swagger\Client\Model\BOLRequestImagesShippingLabels**](BOLRequestImagesShippingLabels.md) |  | [optional] 
**email** | [**\Swagger\Client\Model\BOLRequestImagesEmail**](BOLRequestImagesEmail.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

