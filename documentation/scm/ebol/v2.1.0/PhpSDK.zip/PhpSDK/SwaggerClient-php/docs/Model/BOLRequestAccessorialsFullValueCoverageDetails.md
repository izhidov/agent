# BOLRequestAccessorialsFullValueCoverageDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**monetary_value** | **string** | Value of the cargo.   Valid Formats: * ##.## (2 decimal places only) | [optional] 
**currency** | **string** | Optional attribute to indicate currency of monetaryValue.  Defaults to USD.  Valid values: See the Currencies schema at the bottom of this page. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

