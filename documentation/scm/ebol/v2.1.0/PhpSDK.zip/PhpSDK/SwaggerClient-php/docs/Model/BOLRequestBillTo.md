# BOLRequestBillTo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | **string** | Company&#x27;s account number/id for the billTo. | [optional] 
**location_id** | **string** | Company&#x27;s location id for the billTo. | [optional] 
**name** | **string** | Company name associated with the billTo location. | 
**address1** | **string** | Primary Address line for the billTo location | 
**address2** | **string** | Secondary Address line for the billTo location | [optional] 
**city** | **string** | City Name for the billTo location | 
**state_province** | **string** | Two letter state/province code for the billTo location.  Valid Values: See the State_Province_Codes schema at the bottom of this page. | 
**postal_code** | **string** | The 5-digit + 4 or 5-digit for the United States, 5-digit for Mexico, or 6-character for Canada, postal code for the billTo location.  Valid formats:   * 12345-1234 (5 digits + 4 - USA)   * 12345 (5 digits - USA/MEX)   * A1A1A1 (6 characters - CAN)   * A1A1A (5 characters - CAN) | 
**country** | **string** | Three letter country code for the billTo location.  Valid Values: See the Country_Codes schema at the bottom of this page. | 
**contact** | [**\Swagger\Client\Model\BOLRequestBillToContact**](BOLRequestBillToContact.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

