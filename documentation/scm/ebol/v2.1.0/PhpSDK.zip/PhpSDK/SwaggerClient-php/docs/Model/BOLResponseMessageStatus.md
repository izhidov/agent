# BOLResponseMessageStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **string** | Indicates the status of the request. &lt;br&gt;&lt;br&gt; PASS - Request is successful with no exceptions.&lt;br&gt; FAIL - Request is unsuccessful due to some exception.&lt;br&gt; WARNING - Request is successful with some exception. | [optional] 
**code** | **string** | Indicates response detail code. | [optional] 
**message** | **string** | Provides information pertaining to the response code. | [optional] 
**resolution** | **string** | Provides guidance pertaining to the response code. | [optional] 
**information** | [**\Swagger\Client\Model\BOLResponseMessageStatusInformation[]**](BOLResponseMessageStatusInformation.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

