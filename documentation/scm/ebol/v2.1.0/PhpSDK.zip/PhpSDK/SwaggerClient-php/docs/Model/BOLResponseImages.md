# BOLResponseImages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bol** | **string** | Base 64 encoded PDF of the populated Bill Of Lading.  Any bar code within the image(s) should include the check digit when applicable. | [optional] 
**shipping_labels** | **string** | Base 64 encoded PDF of the populated shipping Labels.  Any bar code within the image(s) should include the check digit when applicable. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

