# BOLRequestNotifications

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phone_number** | **string** | Phone number of contact for updates about shipment movements | [optional] 
**email** | **string** | Email address of contact for updates about shipment movements | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

