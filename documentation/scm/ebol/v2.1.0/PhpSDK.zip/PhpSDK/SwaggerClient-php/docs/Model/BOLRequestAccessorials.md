# BOLRequestAccessorials

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**codes** | **string[]** | An array to hold the list of services requested for the shipment  Valid Values: See the Accessorial_Codes schema at the bottom of this page. | [optional] 
**hazardous_details** | [**\Swagger\Client\Model\BOLRequestAccessorialsHazardousDetails**](BOLRequestAccessorialsHazardousDetails.md) |  | [optional] 
**cod** | [**\Swagger\Client\Model\BOLRequestAccessorialsCod**](BOLRequestAccessorialsCod.md) |  | [optional] 
**sort_and_segregate_details** | [**\Swagger\Client\Model\BOLRequestAccessorialsSortAndSegregateDetails**](BOLRequestAccessorialsSortAndSegregateDetails.md) |  | [optional] 
**full_value_coverage_details** | [**\Swagger\Client\Model\BOLRequestAccessorialsFullValueCoverageDetails**](BOLRequestAccessorialsFullValueCoverageDetails.md) |  | [optional] 
**mark_details** | [**\Swagger\Client\Model\BOLRequestAccessorialsMarkDetails**](BOLRequestAccessorialsMarkDetails.md) |  | [optional] 
**limited_access_type** | [**\Swagger\Client\Model\BOLRequestAccessorialsLimitedAccessType**](BOLRequestAccessorialsLimitedAccessType.md) |  | [optional] 
**time_critical_details** | [**\Swagger\Client\Model\BOLRequestAccessorialsTimeCriticalDetails**](BOLRequestAccessorialsTimeCriticalDetails.md) |  | [optional] 
**appointment_details** | [**\Swagger\Client\Model\BOLRequestAccessorialsAppointmentDetails**](BOLRequestAccessorialsAppointmentDetails.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

