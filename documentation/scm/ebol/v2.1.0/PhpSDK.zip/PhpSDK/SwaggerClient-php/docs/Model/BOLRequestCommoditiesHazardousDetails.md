# BOLRequestCommoditiesHazardousDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weight** | **int** | Total weight of hazardous material coveraged by one description. | [optional] 
**weight_unit** | **string** | The unit of measurement for weight.  Defaults to Pounds (Imperial) if not passed.  Valid Values: Pounds or Kilograms | [optional] 
**class** | **string** | Class that the hazardous material is catogorized by. | [optional] 
**unna_number** | **string** | Proper Identification Number (UN or NA) corresponding to the Proper Shipping Name | [optional] 
**propername** | **string** | Proper shipping name for the hazardous material.  From DOT regulations 172.101 | [optional] 
**technical_name** | **string** | Technical name for the hazardous material. Not all hazardous items will have a technical name. From DOT regulations 172.101 | [optional] 
**packing_group** | **string** | Hazmat Packing Group number. Not all hazmat items have a packing group | [optional] 
**contract_number** | **string** | The contract number with the hazardous materials contact | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

