# Swagger\Client\CarrierAPIStandardsApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**bolV1AppPost**](CarrierAPIStandardsApi.md#bolv1apppost) | **POST** /bol/v1/app/ | Create an Electronic Bill of Lading
[**bolV1AppProDelete**](CarrierAPIStandardsApi.md#bolv1appprodelete) | **DELETE** /bol/v1/app/{pro} | Delete an Electronic Bill of Lading
[**bolV1AppProPut**](CarrierAPIStandardsApi.md#bolv1appproput) | **PUT** /bol/v1/app/{pro} | Update an Electronic Bill of Lading

# **bolV1AppPost**
> \Swagger\Client\Model\BOLResponse bolV1AppPost($body)

Create an Electronic Bill of Lading

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CarrierAPIStandardsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\BOLRequest(); // \Swagger\Client\Model\BOLRequest | 

try {
    $result = $apiInstance->bolV1AppPost($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CarrierAPIStandardsApi->bolV1AppPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\BOLRequest**](../Model/BOLRequest.md)|  |

### Return type

[**\Swagger\Client\Model\BOLResponse**](../Model/BOLResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **bolV1AppProDelete**
> bolV1AppProDelete($pro)

Delete an Electronic Bill of Lading

This operation deletes an existing Electronic Bill of Lading.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CarrierAPIStandardsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$pro = "pro_example"; // string | PRO Number of eBOL to update.

try {
    $apiInstance->bolV1AppProDelete($pro);
} catch (Exception $e) {
    echo 'Exception when calling CarrierAPIStandardsApi->bolV1AppProDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro** | **string**| PRO Number of eBOL to update. |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **bolV1AppProPut**
> \Swagger\Client\Model\BOLResponse bolV1AppProPut($body, $pro)

Update an Electronic Bill of Lading

This operation updates an existing Electronic Bill of Lading.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CarrierAPIStandardsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\BOLRequest(); // \Swagger\Client\Model\BOLRequest | 
$pro = "pro_example"; // string | PRO Number of eBOL to delete.

try {
    $result = $apiInstance->bolV1AppProPut($body, $pro);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CarrierAPIStandardsApi->bolV1AppProPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\BOLRequest**](../Model/BOLRequest.md)|  |
 **pro** | **string**| PRO Number of eBOL to delete. |

### Return type

[**\Swagger\Client\Model\BOLResponse**](../Model/BOLResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

