# BOLRequestCustomsBrokerContact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phone** | **string** | Ten digit phone number, without country code and/or dashes, for the customsBroker location&#x27;s contact person.  Valid Formats: * ########## (10 digits - Area code + phone) | 
**phone_ext** | **string** | Phone extensionfor the customsBroker location&#x27;s contact person. | [optional] 
**name** | **string** | Name of the customsBroker location&#x27;s contact person. | [optional] 
**email** | **string** | Email address of the customsBroker location&#x27;s contact person. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

