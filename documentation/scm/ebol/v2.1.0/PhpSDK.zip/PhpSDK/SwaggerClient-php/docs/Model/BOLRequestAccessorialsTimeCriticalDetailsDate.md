# BOLRequestAccessorialsTimeCriticalDetailsDate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start** | **string** | The date (with or without time) the shipment is requested to be delivered.  Required when timeCriticalDetails.type is populated with any valid value.  Valid Formats: * YYYY-MM-DDTHH:mm:ss.sss (ISO 8601) | [optional] 
**end** | **string** | The end date (with or without time) of the requested delivery window.  Required when the timeCriticalDetails.type is Delivery Window.  Valid Formats: * YYYY-MM-DDTHH:mm:ss.sss (ISO 8601) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

