# BOLRequestCommoditiesLineItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **string** | Description of the freight being described. | 
**weight** | **int** | Total weight for the specified lineItem. | 
**weight_unit** | **string** | The unit of measurement for weight.  Defaults to Pounds (Imperial) if not passed.  Valid Values: Pounds or Kilograms | [optional] 
**pieces** | **int** | Number of individual pieces for the line item being described. | 
**packaging_type** | **string** | Packaging type for the individual pieces of the line item being described.  Valid Values: See the Packaging_Types schema at the bottom of this page | 
**classification** | **string** | Classification of the line item beind described.  Valid Values: See the Classification_Codes schema at the bottom of this page. | 
**nmfc** | **string** | NMFC code of the freight being described. | [optional] 
**nmfc_sub** | **string** | The Sub value for the NMFC of the freight being described. | [optional] 
**hazardous** | **bool** | Identifies whether or not the freight being described contains hazardous materials. | 
**hazardous_description** | **string** | Conditionally required when &#x27;hazardous&#x27; is &#x27;true&#x27;. Provides a detailed description of the hazardous item. | [optional] 
**hazardous_details** | [**\Swagger\Client\Model\BOLRequestCommoditiesHazardousDetails**](BOLRequestCommoditiesHazardousDetails.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

