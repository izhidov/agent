# BOLRequestAccessorialsLimitedAccessType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**origin** | **string** | Optional attribute to indicate the limited access type when accessorial code LTDAP is present in the accessorial.codes list.   Valid Values: See the Limited_Access_Types schema at the bottom of this page. | [optional] 
**destination** | **string** | Optional attribute to indicate the limited access type when accessorial code LTDAD is present in the accessorial.codes list.   Valid Values: See the Limited_Access_Types schema at the bottom of this page. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

