# BOLRequestCommodities

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**line_item_layout** | **string** | Valid values: Nested or Stacked  Nested: Indicates if the Handling Unit/Line Item relationship is known. If this value is used, each Line Item associated to a Handling Unit is conditionally required to be passed within that Handling Unit&#x27;s object.  Stacked: Indicates if the Handling Unit/Line Item relationship is not known.  If this value is used, Line Items may passed within any Handling Unit object. | 
**handling_units** | [**\Swagger\Client\Model\BOLRequestCommoditiesHandlingUnits[]**](BOLRequestCommoditiesHandlingUnits.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

