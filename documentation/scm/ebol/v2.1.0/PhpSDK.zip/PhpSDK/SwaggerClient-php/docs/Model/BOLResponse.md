# BOLResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **string** | Indicates which version of the Digital LTL Council Bill of Lading spec was returned | [optional] 
**transaction_date** | **string** | The date associated with this electronic bill of lading transaction. | [optional] 
**reference_numbers** | [**\Swagger\Client\Model\BOLResponseReferenceNumbers**](BOLResponseReferenceNumbers.md) |  | [optional] 
**scac** | **string** | 4-letter, Standard Carrier Alpha Code, returned by the carrier. | [optional] 
**images** | [**\Swagger\Client\Model\BOLResponseImages**](BOLResponseImages.md) |  | [optional] 
**terms_and_conditions** | **string** | Add terms and conditions here if desired, or a link to your  terms and conditions. | [optional] 
**message_status** | [**\Swagger\Client\Model\BOLResponseMessageStatus**](BOLResponseMessageStatus.md) |  | [optional] 
**result_status_codes** | [**\Swagger\Client\Model\ResultStatusCodes[]**](ResultStatusCodes.md) | Error response | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

