'use strict';


/**
 * Create an Electronic Bill of Lading
 *
 * body BOL_Request 
 * returns BOL_Response
 **/
exports.bolV1AppPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "messageStatus" : {
    "code" : "10000000",
    "information" : [ ],
    "message" : "Transaction was successful.",
    "resolution" : "",
    "status" : "PASS"
  },
  "images" : {
    "bol" : "JVBERi0xLjcKCjQgMCBvYmoKPDwKL0JpdHNQZXJDb21wb25lbnQgOAovQ29sb3JTcGFjZSAvRGV2a......",
    "shippingLabels" : "JVBERi0xLjcKCjQgMCBvYmoKPDwKL0JpdHNQZXJDb21wb25lbnQgOAovQ29sb3JTcGFjZSAvRGV2a......"
  },
  "resultStatusCodes" : [ "", "" ],
  "scac" : "AAAB",
  "transactionDate" : "2022-11-20T00:00:00.000",
  "referenceNumbers" : {
    "shipmentConfirmationNumber" : "SCN1234",
    "pro" : "PRO1234"
  },
  "version" : "2.1.0",
  "termsAndConditions" : "Terms and Conditions text available for download at www.myurl-nmfta.org"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete an Electronic Bill of Lading
 * This operation deletes an existing Electronic Bill of Lading.
 *
 * pro String PRO Number of eBOL to update.
 * no response value expected for this operation
 **/
exports.bolV1AppProDelete = function(pro) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update an Electronic Bill of Lading
 * This operation updates an existing Electronic Bill of Lading.
 *
 * body BOL_Request 
 * pro String PRO Number of eBOL to delete.
 * returns BOL_Response
 **/
exports.bolV1AppProPUT = function(body,pro) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "messageStatus" : {
    "code" : "10000000",
    "information" : [ ],
    "message" : "Transaction was successful.",
    "resolution" : "",
    "status" : "PASS"
  },
  "images" : {
    "bol" : "JVBERi0xLjcKCjQgMCBvYmoKPDwKL0JpdHNQZXJDb21wb25lbnQgOAovQ29sb3JTcGFjZSAvRGV2a......",
    "shippingLabels" : "JVBERi0xLjcKCjQgMCBvYmoKPDwKL0JpdHNQZXJDb21wb25lbnQgOAovQ29sb3JTcGFjZSAvRGV2a......"
  },
  "resultStatusCodes" : [ "", "" ],
  "scac" : "AAAB",
  "transactionDate" : "2022-11-20T00:00:00.000",
  "referenceNumbers" : {
    "shipmentConfirmationNumber" : "SCN1234",
    "pro" : "PRO1234"
  },
  "version" : "2.1.0",
  "termsAndConditions" : "Terms and Conditions text available for download at www.myurl-nmfta.org"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

