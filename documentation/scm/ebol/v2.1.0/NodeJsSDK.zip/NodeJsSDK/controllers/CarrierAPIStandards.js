'use strict';

var utils = require('../utils/writer.js');
var CarrierAPIStandards = require('../service/CarrierAPIStandardsService');

module.exports.bolV1AppPOST = function bolV1AppPOST (req, res, next, body) {
  CarrierAPIStandards.bolV1AppPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.bolV1AppProDelete = function bolV1AppProDelete (req, res, next, pro) {
  CarrierAPIStandards.bolV1AppProDelete(pro)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.bolV1AppProPUT = function bolV1AppProPUT (req, res, next, body, pro) {
  CarrierAPIStandards.bolV1AppProPUT(body, pro)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
