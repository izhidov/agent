# SwaggerClient::AccessorialCodes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

