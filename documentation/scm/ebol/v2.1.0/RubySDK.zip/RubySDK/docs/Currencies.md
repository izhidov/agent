# SwaggerClient::Currencies

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

