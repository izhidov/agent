# SwaggerClient::BOLResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** | Indicates which version of the Digital LTL Council Bill of Lading spec was returned | [optional] 
**transaction_date** | **String** | The date associated with this electronic bill of lading transaction. | [optional] 
**reference_numbers** | [**BOLResponseReferenceNumbers**](BOLResponseReferenceNumbers.md) |  | [optional] 
**scac** | **String** | 4-letter, Standard Carrier Alpha Code, returned by the carrier. | [optional] 
**images** | [**BOLResponseImages**](BOLResponseImages.md) |  | [optional] 
**terms_and_conditions** | **String** | Add terms and conditions here if desired, or a link to your  terms and conditions.     | [optional] 
**message_status** | [**BOLResponseMessageStatus**](BOLResponseMessageStatus.md) |  | [optional] 
**result_status_codes** | [**Array&lt;ResultStatusCodes&gt;**](ResultStatusCodes.md) | Error response | [optional] 

