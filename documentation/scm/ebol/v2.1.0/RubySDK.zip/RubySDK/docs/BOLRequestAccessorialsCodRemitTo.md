# SwaggerClient::BOLRequestAccessorialsCodRemitTo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the remit to company. | [optional] 
**address1** | **String** | Primary Address line of the remit to company. | [optional] 
**address2** | **String** | Secondary Address of the remit to company. | [optional] 
**city** | **String** | City Name of the remit to company. | [optional] 
**state_province** | **String** | Two letter state/province code of the remit to company.  Valid Values: See the State_Province_Codes schema at the bottom of this page.  | [optional] 
**postal_code** | **String** | The 5-digit + 4 or 5-digit for the United States, 5-digit for Mexico, or 6-character for Canada, postal code for the remit to company location.  Valid formats:   * 12345-1234 (5 digits + 4 - USA)   * 12345 (5 digits - USA/MEX)   * A1A1A1 (6 characters - CAN)   * A1A1A (5 characters - CAN)  | [optional] 
**country** | **String** | Three letter country code of the remit to company.  Valid Values: See the Country_Codes schema at the bottom of this page.  | [optional] 

