# SwaggerClient::BOLRequestCommoditiesLineItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** | Description of the freight being described. | 
**weight** | **Integer** | Total weight for the specified lineItem. | 
**weight_unit** | **String** | The unit of measurement for weight.  Defaults to Pounds (Imperial) if not passed.  Valid Values: Pounds or Kilograms  | [optional] 
**pieces** | **Integer** | Number of individual pieces for the line item being described. | 
**packaging_type** | **String** | Packaging type for the individual pieces of the line item being described.  Valid Values: See the Packaging_Types schema at the bottom of this page  | 
**classification** | **String** | Classification of the line item beind described.  Valid Values: See the Classification_Codes schema at the bottom of this page.  | 
**nmfc** | **String** | NMFC code of the freight being described. | [optional] 
**nmfc_sub** | **String** | The Sub value for the NMFC of the freight being described. | [optional] 
**hazardous** | **BOOLEAN** | Identifies whether or not the freight being described contains hazardous materials. | 
**hazardous_description** | **String** | Conditionally required when &#x27;hazardous&#x27; is &#x27;true&#x27;. Provides a detailed description of the hazardous item. | [optional] 
**hazardous_details** | [**BOLRequestCommoditiesHazardousDetails**](BOLRequestCommoditiesHazardousDetails.md) |  | [optional] 

