# SwaggerClient::BOLRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bol** | [**BOLRequestBol**](BOLRequestBol.md) |  | 
**version** | **String** | Indicates which minor version of the Digital LTL Council Bill of Lading spec you are consuming  Valid values: 2.0.0, 2.0.1, 2.1.0  | 
**images** | [**BOLRequestImages**](BOLRequestImages.md) |  | [optional] 
**notifications** | [**Array&lt;BOLRequestNotifications&gt;**](BOLRequestNotifications.md) | include if you want notifications of shipment movements by text message or email | [optional] 
**reference_numbers** | [**BOLRequestReferenceNumbers**](BOLRequestReferenceNumbers.md) |  | [optional] 
**payment** | [**BOLRequestPayment**](BOLRequestPayment.md) |  | 
**commodities** | [**BOLRequestCommodities**](BOLRequestCommodities.md) |  | 
**shipment_totals** | [**BOLRequestShipmentTotals**](BOLRequestShipmentTotals.md) |  | [optional] 
**accessorials** | [**BOLRequestAccessorials**](BOLRequestAccessorials.md) |  | [optional] 
**origin** | [**BOLRequestOrigin**](BOLRequestOrigin.md) |  | 
**destination** | [**BOLRequestDestination**](BOLRequestDestination.md) |  | 
**bill_to** | [**BOLRequestBillTo**](BOLRequestBillTo.md) |  | 
**customs_broker** | [**BOLRequestCustomsBroker**](BOLRequestCustomsBroker.md) |  | [optional] 

