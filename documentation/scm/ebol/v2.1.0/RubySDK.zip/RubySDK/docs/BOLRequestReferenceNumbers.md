# SwaggerClient::BOLRequestReferenceNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pro** | **String** | Shipper&#x27;s pre-assigned PRO number for the requested carrier. If one was not provided in the request, one will be auto assigned by the carrier.  The PRO number value should include the check digit when applicable. | [optional] 
**quote_id** | **String** | Quote (estimate) number provided by the carrier after submitting a rate quote request. | [optional] 
**shipment_id** | **String** | Shipment Id (SID) number for the shipment. | [optional] 
**master_bol** | **String** | Master Bill of Lading number for the shipment. | [optional] 
**trailer_id** | **String** | When passed, indicates that the shipment is associated to a specific, spotted trailer. | [optional] 
**manifest_id** | **String** | When passed, indicates that the shipment is associated to a manifest that includes multiple shipments, possibly across multiple spotted trailers. | [optional] 
**bol** | **Array&lt;String&gt;** |  | [optional] 
**po** | [**Array&lt;BOLRequestReferenceNumbersPo&gt;**](BOLRequestReferenceNumbersPo.md) |  | [optional] 
**additional_references** | [**Array&lt;BOLRequestReferenceNumbersAdditionalReferences&gt;**](BOLRequestReferenceNumbersAdditionalReferences.md) |  | [optional] 

