# SwaggerClient::CarrierAPIStandardsApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**bol_v1_app_post**](CarrierAPIStandardsApi.md#bol_v1_app_post) | **POST** /bol/v1/app/ | Create an Electronic Bill of Lading
[**bol_v1_app_pro_delete**](CarrierAPIStandardsApi.md#bol_v1_app_pro_delete) | **DELETE** /bol/v1/app/{pro} | Delete an Electronic Bill of Lading
[**bol_v1_app_pro_put**](CarrierAPIStandardsApi.md#bol_v1_app_pro_put) | **PUT** /bol/v1/app/{pro} | Update an Electronic Bill of Lading

# **bol_v1_app_post**
> BOLResponse bol_v1_app_post(body)

Create an Electronic Bill of Lading

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CarrierAPIStandardsApi.new
body = SwaggerClient::BOLRequest.new # BOLRequest | 


begin
  #Create an Electronic Bill of Lading
  result = api_instance.bol_v1_app_post(body)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CarrierAPIStandardsApi->bol_v1_app_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BOLRequest**](BOLRequest.md)|  | 

### Return type

[**BOLResponse**](BOLResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **bol_v1_app_pro_delete**
> bol_v1_app_pro_delete(pro)

Delete an Electronic Bill of Lading

This operation deletes an existing Electronic Bill of Lading.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CarrierAPIStandardsApi.new
pro = 'pro_example' # String | PRO Number of eBOL to update.


begin
  #Delete an Electronic Bill of Lading
  api_instance.bol_v1_app_pro_delete(pro)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CarrierAPIStandardsApi->bol_v1_app_pro_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro** | **String**| PRO Number of eBOL to update. | 

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json



# **bol_v1_app_pro_put**
> BOLResponse bol_v1_app_pro_put(bodypro)

Update an Electronic Bill of Lading

This operation updates an existing Electronic Bill of Lading.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CarrierAPIStandardsApi.new
body = SwaggerClient::BOLRequest.new # BOLRequest | 
pro = 'pro_example' # String | PRO Number of eBOL to delete.


begin
  #Update an Electronic Bill of Lading
  result = api_instance.bol_v1_app_pro_put(bodypro)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CarrierAPIStandardsApi->bol_v1_app_pro_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BOLRequest**](BOLRequest.md)|  | 
 **pro** | **String**| PRO Number of eBOL to delete. | 

### Return type

[**BOLResponse**](BOLResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



