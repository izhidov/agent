# SwaggerClient::BOLRequestAccessorialsLimitedAccessType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**origin** | **String** | Optional attribute to indicate the limited access type when accessorial code LTDAP is present in the accessorial.codes list.   Valid Values: See the Limited_Access_Types schema at the bottom of this page.   | [optional] 
**destination** | **String** | Optional attribute to indicate the limited access type when accessorial code LTDAD is present in the accessorial.codes list.   Valid Values: See the Limited_Access_Types schema at the bottom of this page.   | [optional] 

