# SwaggerClient::BOLRequestReferenceNumbersPo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **String** | The Purchase Order number. | [optional] 
**pieces** | **Integer** | Total pieces associated with the Purchase Order | [optional] 
**weight** | **Integer** | Total weight associated with the Purchase Order | [optional] 
**weight_unit** | **String** | The unit of measurement for weight.  Defaults to Pounds (Imperial) if not passed.  Valid Values: Pounds or Kilograms                       | [optional] 
**palletized** | **BOOLEAN** | Indicates whether or not the pieces associated with the purchase order are on a pallet/slip/skid or not. | [optional] 
**additional_shipper_info** | **String** | Additional information from shipper per line item | [optional] 

