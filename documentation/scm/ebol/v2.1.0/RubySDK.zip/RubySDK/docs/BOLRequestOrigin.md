# SwaggerClient::BOLRequestOrigin

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | **String** | Company&#x27;s account number/id for the origin. | [optional] 
**location_id** | **String** | Company&#x27;s location id for the origin | [optional] 
**name** | **String** | Company name associated with the origin location. | 
**address1** | **String** | Primary Address line for the origin location | 
**address2** | **String** | Secondary Address line for the origin location | [optional] 
**city** | **String** | City Name for the origin location | 
**state_province** | **String** | Two letter state/province code for the origin location.  Valid Values: See the State_Province_Codes schema at the bottom of this page.  | 
**postal_code** | **String** | The 5-digit + 4 or 5-digit for the United States, 5-digit for Mexico, or 6-character for Canada, postal code for the origin location.  Valid formats:   * 12345-1234 (5 digits + 4 - USA)   * 12345 (5 digits - USA/MEX)   * A1A1A1 (6 characters - CAN)   * A1A1A (5 characters - CAN)  | 
**country** | **String** | Three letter country code for the origin location.  Valid Values: See the Country_Codes schema at the bottom of this page.  | 
**contact** | [**BOLRequestOriginContact**](BOLRequestOriginContact.md) |  | 

