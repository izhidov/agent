# SwaggerClient::BOLRequestPayment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terms** | **String** | Freight Billing Terms for the shipment  Valid Values: See the Payment_Terms schema at the bottom of this page.  | 

